# Contributors

These are the people who helped improve the Arachni WebUI either by submitting
code, suggestions or testing it.

- [Robert Gouin](mailto:rgouin@webmaxdb.com) for relentless testing.
- [Anton Abashkin](mailto:abashkin.anton@gmail.com) for testing and feedback.
