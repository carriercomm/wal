def killall
    instance_killall
    dispatcher_killall
    process_killall
    process_kill_em
end
