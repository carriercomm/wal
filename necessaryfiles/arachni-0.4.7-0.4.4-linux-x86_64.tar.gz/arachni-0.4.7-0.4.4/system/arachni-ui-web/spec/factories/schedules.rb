# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :schedule do
    type ""
    datetime "2013-09-27 23:02:57"
    scan_id 1
  end
end
