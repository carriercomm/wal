#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/home/zapotek/arachni-build-dir/arachni/system/usr/lib"
XSLT_LIBS="-lxslt  -L/home/zapotek/arachni-build-dir/arachni/system/usr/lib -lxml2 -lm -lm -lrt"
XSLT_INCLUDEDIR="-I/home/zapotek/arachni-build-dir/arachni/system/usr/include"
MODULE_VERSION="xslt-1.1.28"
