##
# Raised when there is an error while building extensions.

class Gem::Ext::BuildError < Gem::InstallError
end

